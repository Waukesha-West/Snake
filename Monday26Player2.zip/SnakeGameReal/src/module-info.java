module SnakeGameReal {
	requires java.desktop;
	requires jdk.compiler;
}